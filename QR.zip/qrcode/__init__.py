from qrcode.main import QRCode, make
from qrcode.constants import *
